
#include "iostream"
using namespace std;
#include "PriorityQueue.hpp"

template<typename ItemType>
PriorityQueue<ItemType>::PriorityQueue()
{
    item_count=0;
    front_= nullptr;
    back_ = nullptr;
}

template<typename ItemType>
 PriorityQueue<ItemType>::PriorityQueue(const PriorityQueue<ItemType>& a_priority_queue)
{
    item_count = 0;
    front_= nullptr;
    back_ = nullptr;

    PriorityNode<ItemType>* current = nullptr;

    for (current = a_priority_queue.front_; current != nullptr; current = current->getNext()) {
        this->enqueue(current->getItem(), current->getPriority());
    }

}

template<typename ItemType>
 PriorityQueue<ItemType>::~PriorityQueue()
{
    PriorityNode<ItemType>* current = front_;

    while (current != NULL) {

        PriorityNode<ItemType>* temp = current;

        current = current->getNext();

        delete temp;
    }
    front_ = back_ = nullptr;

    item_count = 0;
}

template<typename ItemType>
 void PriorityQueue<ItemType>::enqueue(const ItemType & new_entry, int priority)
{
    PriorityNode<ItemType>* newNode = new PriorityNode<ItemType>(new_entry, priority);

    // assign newNode to the back pointer
    if (isEmpty()) {
        front_ = back_ = newNode;
    }
    else {
        back_->setNext(newNode);
    }
    back_ = newNode;

    //increment the size
    ++item_count;
}

template<typename ItemType>
 void PriorityQueue<ItemType>::dequeue()
{
    int minPriority = INT_MAX;

    PriorityNode<ItemType>* current = nullptr;
    for (current = front_; current != nullptr; current = current->getNext())
    {
        if (current->getPriority() < minPriority)
            minPriority = current->getPriority();
    }

    current = nullptr;
    PriorityNode<ItemType>* prev = nullptr;

    if (minPriority == front_->getPriority())
    {
        current = front_;

        front_ = front_->getNext();

        if (nullptr == front_)
            back_ = nullptr;

        delete current;

    }
    else
    {
        for (current = front_; current != nullptr; prev = current, current = current->getNext())
        {
            if (minPriority == current->getPriority())
            {
                break;
            }

        }

        prev->setNext(current->getNext());

        delete current;

    }

    //decrement the size
    --item_count;

}

template<typename ItemType>
 ItemType PriorityQueue<ItemType>::front() const
{
    int minPriority = INT_MAX;

    PriorityNode<ItemType>* current = nullptr;
    for (current = front_; current != nullptr; current = current->getNext())
    {
        if (current->getPriority() < minPriority)
            minPriority = current->getPriority();
    }


    current = nullptr;
    for (current = front_; current != nullptr; current = current->getNext())
    {
        if (current->getPriority() == minPriority)
            break;
    }

    return current->getItem();
}

template<typename ItemType>
 PriorityNode<ItemType>* PriorityQueue<ItemType>::getFrontPtr() const
{
    int minPriority = INT_MAX;

    PriorityNode<ItemType>* current = nullptr;
    for (current = front_; current != nullptr; current = current->getNext())
    {
        if (current->getPriority() < minPriority)
            minPriority = current->getPriority();
    }

    current = nullptr;
    for (current = front_; current != nullptr; current = current->getNext())
    {
        if (current->getPriority() == minPriority)
            break;
    }

    return current;
}

template<typename ItemType>
 int PriorityQueue<ItemType>::size() const
{
    return item_count;
}

template<typename ItemType>
 bool PriorityQueue<ItemType>::isEmpty() const
{
     if (nullptr==front_&&nullptr == back_&&0 == item_count){
         return true;
     }

}


